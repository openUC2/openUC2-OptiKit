/* @ts-self-types="./oc_wasm.d.ts" */

/**
 * The opaque handle JS holds. Owns the authoritative scene.
 */
export class Canvas {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CanvasFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_canvas_free(ptr, 0);
    }
    /**
     * The glass scatter as JSON: `[{"name","nd","vd"}, ...]`.
     * @returns {string}
     */
    abbeGlassesJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_abbeGlassesJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The convex hull of the real-glass region as a flat `[vd, nd, ...]` list.
     * Outside it, glass is "unobtainable" (hatch it in the UI).
     * @returns {Float64Array}
     */
    abbeHull() {
        const ret = wasm.canvas_abbeHull(this.__wbg_ptr);
        var v1 = getArrayF64FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 8, 8);
        return v1;
    }
    /**
     * @returns {number}
     */
    activeLayer() {
        const ret = wasm.canvas_activeLayer(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Add a circular aperture stop at `(x,y)`, opening radius `opening` mm,
     * tilted `tilt_deg`. Rays inside the opening pass; the rest are absorbed.
     * Returns the new object id. Bumps the revision.
     * @param {number} x
     * @param {number} y
     * @param {number} opening
     * @param {number} tilt_deg
     * @returns {number}
     */
    addAperture(x, y, opening, tilt_deg) {
        const ret = wasm.canvas_addAperture(this.__wbg_ptr, x, y, opening, tilt_deg);
        return ret;
    }
    /**
     * Add a square area detector at `(x,y)`, half-size `half` mm, its face normal
     * tilted `tilt_deg` in the meridional plane (same convention as surfaces and
     * apertures). 64×64 bins. Returns the new object id. Bumps the revision.
     * @param {number} x
     * @param {number} y
     * @param {number} half
     * @param {number} tilt_deg
     * @returns {number}
     */
    addAreaDetector(x, y, half, tilt_deg) {
        const ret = wasm.canvas_addAreaDetector(this.__wbg_ptr, x, y, half, tilt_deg);
        return ret;
    }
    /**
     * Add a collimated monochromatic source. `aim_deg` is the beam direction.
     * @param {number} x
     * @param {number} y
     * @param {number} aim_deg
     * @param {number} half_width
     * @param {number} rays
     * @param {number} lambda_um
     */
    addCollimatedSource(x, y, aim_deg, half_width, rays, lambda_um) {
        wasm.canvas_addCollimatedSource(this.__wbg_ptr, x, y, aim_deg, half_width, rays, lambda_um);
    }
    /**
     * Add a detector segment. Returns its index.
     * @param {number} x0
     * @param {number} y0
     * @param {number} x1
     * @param {number} y1
     * @param {number} bins
     * @returns {number}
     */
    addDetector(x0, y0, x1, y1, bins) {
        const ret = wasm.canvas_addDetector(this.__wbg_ptr, x0, y0, x1, y1, bins);
        return ret >>> 0;
    }
    /**
     * Commit a freehand stroke as an optical element: fit the stroke, extrude
     * the selected rung's surface into a thin glass body, and add it. Pass
     * `rung = -1` to use the auto-selected rung. Returns the new element id, or
     * `-1` for a degenerate stroke.
     * @param {Float64Array} flat_xy
     * @param {number} tol_um
     * @param {number} rung
     * @param {number} thickness
     * @param {number} nd
     * @param {number} vd
     * @param {boolean} mirror
     * @returns {number}
     */
    addFittedElement(flat_xy, tol_um, rung, thickness, nd, vd, mirror) {
        const ptr0 = passArrayF64ToWasm0(flat_xy, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_addFittedElement(this.__wbg_ptr, ptr0, len0, tol_um, rung, thickness, nd, vd, mirror);
        return ret;
    }
    /**
     * Add a new (visible) layer; returns its id.
     * @param {string} name
     * @returns {number}
     */
    addLayer(name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_addLayer(this.__wbg_ptr, ptr0, len0);
        return ret >>> 0;
    }
    /**
     * Add a plane mirror segment from `(x0,y0)` to `(x1,y1)`.
     * @param {number} x0
     * @param {number} y0
     * @param {number} x1
     * @param {number} y1
     * @returns {number}
     */
    addMirror(x0, y0, x1, y1) {
        const ret = wasm.canvas_addMirror(this.__wbg_ptr, x0, y0, x1, y1);
        return ret >>> 0;
    }
    /**
     * Add a round optical element (a flat plate) at `(x,y)`, radius `radius` mm,
     * tilted `tilt_deg` in the meridional plane. Defaults to a front-surface
     * mirror (front reflective, back clear); reconfigure with `setSurfaceResponse`.
     * Returns the new object id. Bumps the revision.
     * @param {number} x
     * @param {number} y
     * @param {number} radius
     * @param {number} tilt_deg
     * @returns {number}
     */
    addPlanarElement(x, y, radius, tilt_deg) {
        const ret = wasm.canvas_addPlanarElement(this.__wbg_ptr, x, y, radius, tilt_deg);
        return ret;
    }
    /**
     * Add a planar mirror spanning the meridional segment `(ax,ay)`→`(bx,by)`
     * (view-plane mm) — the "draw a fold mirror" tool. Returns the new object id,
     * or `-1` for a degenerate segment / no scene. Bumps the revision.
     * @param {number} ax
     * @param {number} ay
     * @param {number} bx
     * @param {number} by
     * @param {number} reflectivity
     * @returns {number}
     */
    addPlanarMirror(ax, ay, bx, by, reflectivity) {
        const ret = wasm.canvas_addPlanarMirror(this.__wbg_ptr, ax, ay, bx, by, reflectivity);
        return ret;
    }
    /**
     * Add a glass prism at `(x,y)`: an equilateral triangle of side `side` mm,
     * extruded out of plane, glass `(nd,vd)`, tilted `tilt_deg`. Returns the new
     * body id. Bumps the revision.
     * @param {number} x
     * @param {number} y
     * @param {number} side
     * @param {number} tilt_deg
     * @param {number} nd
     * @param {number} vd
     * @returns {number}
     */
    addPrism(x, y, side, tilt_deg, nd, vd) {
        const ret = wasm.canvas_addPrism(this.__wbg_ptr, x, y, side, tilt_deg, nd, vd);
        return ret;
    }
    /**
     * Add a biconvex singlet centred at `(x, y)`. Returns its element id.
     * @param {number} x
     * @param {number} y
     * @param {number} radius
     * @param {number} thickness
     * @param {number} half_ap
     * @param {number} nd
     * @param {number} vd
     * @returns {number}
     */
    addSinglet(x, y, radius, thickness, half_ap, nd, vd) {
        const ret = wasm.canvas_addSinglet(this.__wbg_ptr, x, y, radius, thickness, half_ap, nd, vd);
        return ret >>> 0;
    }
    /**
     * Add a collimated white beam. Sampled with a dense equal-energy spectrum
     * (`lines` wavelengths across the visible) so the additive sum is neutral
     * white and dispersion resolves as a smooth rainbow (§5.4/§5.5).
     * @param {number} x
     * @param {number} y
     * @param {number} aim_deg
     * @param {number} half_width
     * @param {number} rays
     * @param {number} lines
     */
    addWhiteBeam(x, y, aim_deg, half_width, rays, lines) {
        wasm.canvas_addWhiteBeam(this.__wbg_ptr, x, y, aim_deg, half_width, rays, lines);
    }
    /**
     * An aperture's clear opening as `{"inner","outer"}` (min / max radius that
     * passes, mm), or `null` if `id` is not an aperture. A plain disc opening
     * reports `inner: 0`.
     * @param {number} id
     * @returns {string}
     */
    apertureOpeningJSON(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_apertureOpeningJSON(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * An extruded body's local profile + z-extents, for drawing a prism in 3D:
     * `{zMin, zMax, points:[[x,y],...]}` (polygon vertices, local frame), or
     * `null` if `id` is not an extruded profile body.
     * @param {number} id
     * @returns {string}
     */
    bodyExtrudeJSON(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_bodyExtrudeJSON(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * A body's bulk glass as JSON `{nd,vd}` (an Abbe point), or `null` if `id` is
     * not a body or its material is not an Abbe point (catalog glass, mirror, …).
     * @param {number} id
     * @returns {string}
     */
    bodyGlassJSON(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_bodyGlassJSON(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {boolean}
     */
    canRedo() {
        const ret = wasm.canvas_canRedo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    canUndo() {
        const ret = wasm.canvas_canUndo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * The capability report for the loaded scene (§3.5): which physics the f64
     * reference supports, approximates, or rejects, each with the object. JSON
     * `{supported,exact,approximated,rejected}`, or `null` if none is loaded.
     * @returns {string}
     */
    capabilityReportJSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_capabilityReportJSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Duplicate a body offset by `(dx,dy,dz)`, with fresh ids. Returns the new
     * body id, or `-1` if `id` is not a body. Bumps the revision.
     * @param {number} id
     * @param {number} dx
     * @param {number} dy
     * @param {number} dz
     * @returns {number}
     */
    cloneBody3D(id, dx, dy, dz) {
        const ret = wasm.canvas_cloneBody3D(this.__wbg_ptr, id, dx, dy, dz);
        return ret;
    }
    /**
     * Serialize an element to a JSON string for the clipboard. Robust to later
     * deletions/re-indexing (unlike an id), so copy → delete → paste is safe.
     * Returns `"null"` if there is no such element.
     * @param {number} id
     * @returns {string}
     */
    cloneElementJson(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_cloneElementJson(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Snapshot the current state as a new child of the current node and move
     * there (§5.2). Returns the new node id, or -1 if nothing changed.
     * @param {string} label
     * @returns {number}
     */
    commit(label) {
        const ptr0 = passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_commit(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @returns {number}
     */
    currentHistoryNode() {
        const ret = wasm.canvas_currentHistoryNode(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Delete an element and re-index the fitted-surface and pin tables so ids
     * stay equal to positions (the scene uses index ids). Returns true if an
     * element was removed. The caller must clear/relocate its own `selected`.
     * @param {number} id
     * @returns {boolean}
     */
    deleteElement(id) {
        const ret = wasm.canvas_deleteElement(this.__wbg_ptr, id);
        return ret !== 0;
    }
    /**
     * Delete any object or source by id. Bumps the revision. `false` if nothing
     * matched.
     * @param {number} id
     * @returns {boolean}
     */
    deleteObject3D(id) {
        const ret = wasm.canvas_deleteObject3D(this.__wbg_ptr, id);
        return ret !== 0;
    }
    /**
     * Per-hit spot-diagram records for the area detector with id `detector_id`,
     * same flat f32 layout as [`Canvas::first_detector_hits_f32`]. Empty if there
     * is no 3D scene or no such detector. Lets the browser show whichever
     * detector is selected when a scene has several.
     * @param {number} detector_id
     * @returns {Float32Array}
     */
    detectorHitsF32(detector_id) {
        const ret = wasm.canvas_detectorHitsF32(this.__wbg_ptr, detector_id);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Reference (f64) detector readout as JSON — the honest numbers (§4.1).
     * `{"hits","flux","centroid","opl","bins":[...]}`; `null` if no such
     * detector or no hits.
     * @param {number} idx
     * @returns {string}
     */
    detectorJson(idx) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_detectorJson(this.__wbg_ptr, idx);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The f64 reference readout for a detector by id (§4.1: the honest numbers).
     * JSON `{hits, totalIncident, totalSignal, cellArea, centroid, meanOpl,
     * bins, incident}`, or `null` if there is no such detector.
     * @param {number} detector_id
     * @returns {string}
     */
    detectorResultJSON(detector_id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_detectorResultJSON(this.__wbg_ptr, detector_id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    elementCount() {
        const ret = wasm.canvas_elementCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * The fitted ladder for a committed element (§5.3), for the inspector's
     * complexity slider: `{current, chosen, tol_um, rungs:[{level,name,dof,
     * residual_um,rms_um}]}`. `null` if `id` is not a fitted element.
     * @param {number} id
     * @returns {string}
     */
    elementFitJson(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_elementFitJson(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The element's boundary as a closed world-space polyline `[x,y,…]` — for
     * drawing the actual optic (so a freehand-drawn surface is visible).
     * @param {number} id
     * @returns {Float32Array}
     */
    elementOutline(id) {
        const ret = wasm.canvas_elementOutline(this.__wbg_ptr, id);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * The element's rigid transform: `{"x","y","rot_deg"}`, or `null`.
     * @param {number} id
     * @returns {string}
     */
    elementTransformJson(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_elementTransformJson(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Per-element metadata for drawing handles / ghosting locked elements:
     * `[{"id","x","y","rot_deg","locked","kind"}]`. `kind` is
     * `singlet|fitted|mirror|other`.
     * @returns {string}
     */
    elementsOverlayJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_elementsOverlayJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Per-hit records on the scene's first area detector, for a **spot diagram**
     * (§6.9): the actual ray-detector intersection points, not a binned grid.
     * One trace with hit-recording on (bounded); flat f32 layout
     * `[halfW, halfH, n, (u, v, r, g, b, flux) × n]` where `(u,v)` are the
     * detector-local mm coordinates and `(r,g,b)` the linear-light wavelength
     * colour (same convention as the ray renderer). Empty if no 3D scene /
     * detector. Records are capped at `max_records`, so a very dense beam shows a
     * representative sample rather than every ray.
     * @returns {Float32Array}
     */
    firstDetectorHitsF32() {
        const ret = wasm.canvas_firstDetectorHitsF32(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * The f64 readout for the scene's first area detector (the common case: one
     * detector), same JSON as [`Canvas::detector_result_json`], or `null` if
     * there is no 3D scene or no detector. Saves the browser from tracking ids
     * for the default single-detector scene.
     * @returns {string}
     */
    firstDetectorResultJSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_firstDetectorResultJSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The first source's kind + params, for the picker UI to initialise:
     * `{kind, p0, p1, samples}`, or `null` if there is no source.
     * @returns {string}
     */
    firstSourceJSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_firstSourceJSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The first source's wavelengths in nanometres (weights folded in as repeated
     * samples are not — this returns the distinct lines), as a JSON array
     * `[{nm, weight}]`, or `null` if there is no source.
     * @returns {string}
     */
    firstSourceWavelengthsJSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_firstSourceWavelengthsJSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Fit a freehand stroke (`flat_xy` = `[x0,y0,x1,y1,...]`, world mm) against
     * the whole complexity ladder **without committing** — the live preview
     * while drawing. Returns JSON:
     * `{chosen, tol_um, rungs:[{level,name,dof,residual_um,rms_um,curve:[x,y,…]}]}`.
     * `curve` is a sampled polyline of that rung's fitted surface, so the
     * complexity slider can redraw any rung for free (no refit).
     * @param {Float64Array} flat_xy
     * @param {number} tol_um
     * @returns {string}
     */
    fitStroke(flat_xy, tol_um) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ptr0 = passArrayF64ToWasm0(flat_xy, wasm.__wbindgen_malloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.canvas_fitStroke(this.__wbg_ptr, ptr0, len0, tol_um);
            deferred2_0 = ret[0];
            deferred2_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * The whole undo tree for the sidebar (§5.2) / variation gallery (§5.6):
     * `{current, nodes:[{id,seq,parent,label,children:[…]}]}`.
     * @returns {string}
     */
    historyJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_historyJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Jump to an arbitrary node — a branch click in the sidebar or a variant
     * in the gallery (§5.6). Returns true if the id is valid.
     * @param {number} id
     * @returns {boolean}
     */
    historyJumpTo(id) {
        const ret = wasm.canvas_historyJumpTo(this.__wbg_ptr, id);
        return ret !== 0;
    }
    /**
     * Reset the history to a single root node snapshotting the current state.
     * The shell calls this once after building its demo scene, so undo does
     * not walk back into the empty start document.
     * @param {string} label
     */
    historyReset(label) {
        const ptr0 = passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.canvas_historyReset(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {number} id
     * @returns {boolean}
     */
    isElementLocked(id) {
        const ret = wasm.canvas_isElementLocked(this.__wbg_ptr, id);
        return ret !== 0;
    }
    /**
     * Is `(n_d, V_d)` a physically obtainable glass (inside the hull)?
     * @param {number} nd
     * @param {number} vd
     * @returns {boolean}
     */
    isObtainable(nd, vd) {
        const ret = wasm.canvas_isObtainable(this.__wbg_ptr, nd, vd);
        return ret !== 0;
    }
    /**
     * @param {number} id
     * @param {string} name
     * @returns {boolean}
     */
    isParamPinned(id, name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_isParamPinned(this.__wbg_ptr, id, ptr0, len0);
        return ret !== 0;
    }
    /**
     * All layers: `[{id,name,visible,opacity,count}]`, `count` = elements on
     * the layer.
     * @returns {string}
     */
    layersJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_layersJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Replace the whole scene from an `.ocanvas` document (the "Open…" action).
     * The JSON is version-checked (a future-version file is rejected), then the
     * scene, pins, active layer, and freehand-fit state are reset and the undo
     * history is re-rooted so undo cannot walk back into the previous document.
     * Throws with a readable message if the document is not loadable.
     * @param {string} json
     */
    loadJSON(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_loadJSON(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Open an `.ocanvas` document of either version into the canonical 3D scene.
     * v1 is migrated with **no third dimension invented** (bodies become
     * `PlanarOnly`); v2 parses directly (§11.2). Returns a load-report JSON:
     * `{dimension, migratedFromV1, unresolvedThirdDimension, planarOnlyBodies,
     * lineProbeDetectors, legacySources, notes, previewMode}`. Throws with a
     * readable message if the document is not loadable.
     * @param {string} json
     * @returns {string}
     */
    loadScene3JSON(json) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.canvas_loadScene3JSON(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    maxGhostBounces() {
        const ret = wasm.canvas_maxGhostBounces(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {number} id
     * @param {number} x
     * @param {number} y
     */
    moveElement(id, x, y) {
        wasm.canvas_moveElement(this.__wbg_ptr, id, x, y);
    }
    constructor() {
        const ret = wasm.canvas_new();
        this.__wbg_ptr = ret;
        CanvasFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Initialize the canonical 3D scene to the default authoring scene: a
     * biconvex singlet at the origin, a collimated beam from the left, and an
     * area detector near the focus. Bumps the revision. Returns the singlet's
     * body id, so the browser can select it.
     * @returns {number}
     */
    newDefaultScene3() {
        const ret = wasm.canvas_newDefaultScene3(this.__wbg_ptr);
        return ret;
    }
    /**
     * Reference (f64) detector readout for a saved node, so variants are
     * compared on the *same* detector (§5.6). `{hits,flux,centroid,opl}`, or
     * `null`.
     * @param {number} id
     * @param {number} idx
     * @returns {string}
     */
    nodeDetectorJson(id, idx) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_nodeDetectorJson(this.__wbg_ptr, id, idx);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * A one-line summary of a node for the gallery card:
     * `{label,seq,elements,sources,detectors}`, or `null`.
     * @param {number} id
     * @returns {string}
     */
    nodeSummaryJson(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_nodeSummaryJson(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Paste a previously [`clone_element_json`]'d element, offset by `(dx, dy)`
     * world units. The paste is unlocked and editable. Returns the new element
     * id, or `-1` if the JSON did not parse. (A pasted freehand element is a
     * plain body — its fit ladder is not carried, so it has no complexity
     * slider; its geometry is preserved exactly.)
     * @param {string} json
     * @param {number} dx
     * @param {number} dy
     * @returns {number}
     */
    pasteElement(json, dx, dy) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_pasteElement(this.__wbg_ptr, ptr0, len0, dx, dy);
        return ret;
    }
    /**
     * The pinned parameter names for an element, as a JSON string array.
     * @param {number} id
     * @returns {string}
     */
    pinnedParamsJson(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_pinnedParamsJson(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * How the browser should preview the scene (§10.3): `"exact_planar"`,
     * `"full_3d"`, `"legacy_planar"`, or `"none"` when nothing is loaded. This
     * is the badge; it never labels a legacy result full 3D.
     * @returns {string}
     */
    previewMode() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_previewMode(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Move to the most recently created child, restoring it. True if it moved.
     * @returns {boolean}
     */
    redo() {
        const ret = wasm.canvas_redo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Remove a layer, merging its elements onto layer 0 and re-indexing the
     * `layer` field of every element above it. The last layer cannot be
     * removed. Returns true on success.
     * @param {number} id
     * @returns {boolean}
     */
    removeLayer(id) {
        const ret = wasm.canvas_removeLayer(this.__wbg_ptr, id);
        return ret !== 0;
    }
    /**
     * @param {number} id
     * @param {string} name
     * @returns {boolean}
     */
    renameLayer(id, name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_renameLayer(this.__wbg_ptr, id, ptr0, len0);
        return ret !== 0;
    }
    /**
     * @param {number} id
     * @param {number} rot
     */
    rotateElement(id, rot) {
        wasm.canvas_rotateElement(this.__wbg_ptr, id, rot);
    }
    /**
     * The canonical 3D scene as v2 JSON, or `""` if none is loaded.
     * @returns {string}
     */
    scene3JSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_scene3JSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The optical elements' cross-section with the view plane (§10.4), for
     * drawing the 2D layout — a lens as its meridional profile, a sphere as a
     * circle, a mirror or detector as a line. A JSON array of polylines
     * `[{kind, closed, pts:[u,v,...]}]` in view-plane coordinates; `[]` if no
     * scene is loaded.
     * @returns {string}
     */
    sceneCrossSectionJSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_sceneCrossSectionJSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The loaded scene's dimension (`3`), or `0` if no 3D scene is loaded.
     * @returns {number}
     */
    sceneDimension() {
        const ret = wasm.canvas_sceneDimension(this.__wbg_ptr);
        return ret;
    }
    /**
     * The 3D objects for the inspector: each body's id, geometry kind, 3D
     * construction, whether its third dimension is resolved, and its world
     * position. JSON array `[{id,kind,construction,is3d,pos:[x,y,z]}]`; empty if
     * no scene is loaded. This is where "construction and missing depth are
     * visible" (§13).
     * @returns {string}
     */
    sceneObjectsJSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_sceneObjectsJSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The current scene revision. A settled f64 result carries the revision it
     * was traced at; the UI discards a result whose revision is not the latest.
     * @returns {number}
     */
    sceneRevision() {
        const ret = wasm.canvas_sceneRevision(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {number} id
     */
    setActiveLayer(id) {
        wasm.canvas_setActiveLayer(this.__wbg_ptr, id);
    }
    /**
     * Set an aperture's clear opening to the ring `inner..outer` mm (min / max
     * radius that passes). `inner = 0` is a plain hole; a positive inner radius
     * adds a central obstruction. Bumps the revision. `false` (scene unchanged)
     * if the radii are invalid (`0 <= inner < outer` required) or `id` is not an
     * aperture.
     * @param {number} id
     * @param {number} inner
     * @param {number} outer
     * @returns {boolean}
     */
    setApertureOpening(id, inner, outer) {
        const ret = wasm.canvas_setApertureOpening(this.__wbg_ptr, id, inner, outer);
        return ret !== 0;
    }
    /**
     * Set a body's bulk glass to an Abbe point `(nd, vd)`. Bumps the revision.
     * `false` if `id` is not a body.
     * @param {number} id
     * @param {number} nd
     * @param {number} vd
     * @returns {boolean}
     */
    setBodyGlassAbbe(id, nd, vd) {
        const ret = wasm.canvas_setBodyGlassAbbe(this.__wbg_ptr, id, nd, vd);
        return ret !== 0;
    }
    /**
     * Move a body so its world position becomes `(x, y, z)` — the drag authoring
     * action (§10.5: an in-plane move translates the body). Bumps the revision.
     * Returns `false` if there is no such body.
     * @param {number} body_id
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {boolean}
     */
    setBodyPosition(body_id, x, y, z) {
        const ret = wasm.canvas_setBodyPosition(this.__wbg_ptr, body_id, x, y, z);
        return ret !== 0;
    }
    /**
     * Apply an Abbe-map point `(n_d, V_d)` to an element (the picker's live
     * feedback, §5.4). Uses the closed-form Cauchy dispersion.
     * @param {number} id
     * @param {number} nd
     * @param {number} vd
     */
    setElementAbbe(id, nd, vd) {
        wasm.canvas_setElementAbbe(this.__wbg_ptr, id, nd, vd);
    }
    /**
     * Move a fitted element to a different rung of its ladder (the complexity
     * slider, §5.3) — re-extrudes the body in place. Returns the new max
     * residual in microns, or `-1` if `id` is not a fitted element / is pinned.
     * @param {number} id
     * @param {number} rung
     * @returns {number}
     */
    setElementFitRung(id, rung) {
        const ret = wasm.canvas_setElementFitRung(this.__wbg_ptr, id, rung);
        return ret;
    }
    /**
     * Snap an element to a named catalog glass (full Sellmeier). Returns true
     * if the name was found.
     * @param {number} id
     * @param {string} name
     * @returns {boolean}
     */
    setElementGlass(id, name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_setElementGlass(this.__wbg_ptr, id, ptr0, len0);
        return ret !== 0;
    }
    /**
     * Assign an element to a layer (§5.6). Returns true on success.
     * @param {number} elem_id
     * @param {number} layer_id
     * @returns {boolean}
     */
    setElementLayer(elem_id, layer_id) {
        const ret = wasm.canvas_setElementLayer(this.__wbg_ptr, elem_id, layer_id);
        return ret !== 0;
    }
    /**
     * Lock (or unlock) a whole element — it then rejects every edit and is
     * drawn ghosted in the UI (§5.1). Returns the new locked state.
     * @param {number} id
     * @param {boolean} locked
     * @returns {boolean}
     */
    setElementLocked(id, locked) {
        const ret = wasm.canvas_setElementLocked(this.__wbg_ptr, id, locked);
        return ret !== 0;
    }
    /**
     * Set position, honouring per-axis pins and the element lock (§5.2). A
     * pinned coordinate keeps its current value. Returns true if anything moved.
     * @param {number} id
     * @param {number} x
     * @param {number} y
     * @returns {boolean}
     */
    setElementPos(id, x, y) {
        const ret = wasm.canvas_setElementPos(this.__wbg_ptr, id, x, y);
        return ret !== 0;
    }
    /**
     * Set rotation in degrees, honouring the `rot` pin and lock.
     * @param {number} id
     * @param {number} deg
     * @returns {boolean}
     */
    setElementRotDeg(id, deg) {
        const ret = wasm.canvas_setElementRotDeg(this.__wbg_ptr, id, deg);
        return ret !== 0;
    }
    /**
     * Toggle the ghost layer (Fresnel back-reflections, §5.5).
     * @param {boolean} on
     */
    setGhosts(on) {
        wasm.canvas_setGhosts(this.__wbg_ptr, on);
    }
    /**
     * @param {number} id
     * @param {number} opacity
     * @returns {boolean}
     */
    setLayerOpacity(id, opacity) {
        const ret = wasm.canvas_setLayerOpacity(this.__wbg_ptr, id, opacity);
        return ret !== 0;
    }
    /**
     * @param {number} id
     * @param {boolean} visible
     * @returns {boolean}
     */
    setLayerVisible(id, visible) {
        const ret = wasm.canvas_setLayerVisible(this.__wbg_ptr, id, visible);
        return ret !== 0;
    }
    /**
     * Set the ghost reflection-generation cap `G` (§4.2): how many nested
     * Fresnel back-reflections to follow. `0` = none, `1` = single ghosts, `2`
     * = ghosts-of-ghosts, … This is the ray-explosion knob; the number of
     * *elements* is unlimited (the primary path auto-sizes to the scene).
     * @param {number} g
     */
    setMaxGhostBounces(g) {
        wasm.canvas_setMaxGhostBounces(this.__wbg_ptr, g);
    }
    /**
     * Move any object or source by id in world space (§10.5). Bumps the
     * revision. `false` if no object has that id or there is no 3D scene.
     * @param {number} id
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @returns {boolean}
     */
    setObjectPosition(id, x, y, z) {
        const ret = wasm.canvas_setObjectPosition(this.__wbg_ptr, id, x, y, z);
        return ret !== 0;
    }
    /**
     * Rotate an object in the meridional plane (right-handed about +Z), degrees.
     * Bumps the revision. `false` if no object has that id.
     * @param {number} id
     * @param {number} deg
     * @returns {boolean}
     */
    setObjectRotationZDeg(id, deg) {
        const ret = wasm.canvas_setObjectRotationZDeg(this.__wbg_ptr, id, deg);
        return ret !== 0;
    }
    /**
     * Pin (or unpin) a single named parameter of an element: one of
     * `x`,`y`,`rot`,`radius`,`thickness`,`conic_k`,`half_ap`,`fit`. Returns the
     * new pinned state.
     * @param {number} id
     * @param {string} name
     * @param {boolean} pinned
     * @returns {boolean}
     */
    setParamPinned(id, name, pinned) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_setParamPinned(this.__wbg_ptr, id, ptr0, len0, pinned);
        return ret !== 0;
    }
    /**
     * Replace a singlet body's geometry. Refuses (returns `false`, scene
     * unchanged) if `id` is not a singlet or the geometry is not revolvable — a
     * bad card edit never corrupts the scene. Bumps the revision on success.
     * @param {number} id
     * @param {number} r1
     * @param {number} r2
     * @param {number} thickness
     * @param {number} semi_aperture
     * @param {number} conic1
     * @param {number} conic2
     * @returns {boolean}
     */
    setSingletGeom(id, r1, r2, thickness, semi_aperture, conic1, conic2) {
        const ret = wasm.canvas_setSingletGeom(this.__wbg_ptr, id, r1, r2, thickness, semi_aperture, conic1, conic2);
        return ret !== 0;
    }
    /**
     * Rebuild a singlet from **per-surface** numeric parameters (the inspector's
     * numeric twin, §5.2). The two faces are independent: `radius1`/`radius2`,
     * `half_ap1`/`half_ap2`, `conic_k1`/`conic_k2`. Each parameter honours its
     * own pin; the whole edit honours the element lock. Returns true on success.
     * @param {number} id
     * @param {number} radius1
     * @param {number} radius2
     * @param {number} thickness
     * @param {number} half_ap1
     * @param {number} half_ap2
     * @param {number} conic_k1
     * @param {number} conic_k2
     * @returns {boolean}
     */
    setSingletParams(id, radius1, radius2, thickness, half_ap1, half_ap2, conic_k1, conic_k2) {
        const ret = wasm.canvas_setSingletParams(this.__wbg_ptr, id, radius1, radius2, thickness, half_ap1, half_ap2, conic_k1, conic_k2);
        return ret !== 0;
    }
    /**
     * Slice half-thickness in mm for filtering projected paths by distance from
     * the plane (§10.4). `0` shows everything projected.
     * @param {number} mm
     */
    setSliceThickness(mm) {
        wasm.canvas_setSliceThickness(this.__wbg_ptr, mm);
    }
    /**
     * Reconfigure the scene's first source (the light-source picker, §6.6).
     * `kind` ∈ `collimated_rect` (p0 = ⌀Y, p1 = ⌀X mm) / `collimated_disc`
     * (p0 = ⌀ mm) / `point` (p0 = cone half-angle °) / `lambertian` (p0 = ⌀ mm);
     * `samples` is the ray count. Bumps the revision. `false` if no scene/source
     * or an unknown kind.
     * @param {string} kind
     * @param {number} p0
     * @param {number} p1
     * @param {number} samples
     * @returns {boolean}
     */
    setSourceConfig(kind, p0, p1, samples) {
        const ptr0 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_setSourceConfig(this.__wbg_ptr, ptr0, len0, p0, p1, samples);
        return ret !== 0;
    }
    /**
     * Set the spatial ray count of a source — raise it to fill the beam into a
     * continuous, homogeneous wavefront (brightness is flux-normalized, so the
     * picture stays balanced as rays fill in).
     * @param {number} idx
     * @param {number} rays
     */
    setSourceRays(idx, rays) {
        wasm.canvas_setSourceRays(this.__wbg_ptr, idx, rays);
    }
    /**
     * Set the spatial ray count of the scene's first source (the ray-density
     * control). Bumps the revision. `false` if there is no 3D scene or source.
     * @param {number} samples
     * @returns {boolean}
     */
    setSourceSamples(samples) {
        const ret = wasm.canvas_setSourceSamples(this.__wbg_ptr, samples);
        return ret !== 0;
    }
    /**
     * Set the first source's wavelengths. `nm` are the wavelengths in nanometres
     * and `weights` their relative weights (equal weights if `weights` is empty
     * or a different length). At least one positive wavelength is required.
     * Bumps the revision. `false` if there is no source or no usable line.
     * @param {Float64Array} nm
     * @param {Float64Array} weights
     * @returns {boolean}
     */
    setSourceWavelengths(nm, weights) {
        const ptr0 = passArrayF64ToWasm0(nm, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayF64ToWasm0(weights, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_setSourceWavelengths(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret !== 0;
    }
    /**
     * Set a surface object's front/back responses (`mirror`/`absorb`/`clear`/
     * `refract`). Bumps the revision. `false` for an unknown kind / non-surface.
     * @param {number} id
     * @param {string} front
     * @param {string} back
     * @returns {boolean}
     */
    setSurfaceResponse(id, front, back) {
        const ptr0 = passStringToWasm0(front, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(back, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.canvas_setSurfaceResponse(this.__wbg_ptr, id, ptr0, len0, ptr1, len1);
        return ret !== 0;
    }
    /**
     * Set a surface object's meridional tilt (its normal's X–Y angle, degrees).
     * Bumps the revision. `false` for a non-surface id.
     * @param {number} id
     * @param {number} deg
     * @returns {boolean}
     */
    setSurfaceTiltZDeg(id, deg) {
        const ret = wasm.canvas_setSurfaceTiltZDeg(this.__wbg_ptr, id, deg);
        return ret !== 0;
    }
    /**
     * Set the plane the 2D Canvas slices/projects (§10.1). `u` and `v` are the
     * in-plane axes; they must be perpendicular. Throws on a degenerate or
     * sheared basis. The view is derived, so this does not bump the revision.
     * @param {number} ox
     * @param {number} oy
     * @param {number} oz
     * @param {number} ux
     * @param {number} uy
     * @param {number} uz
     * @param {number} vx
     * @param {number} vy
     * @param {number} vz
     */
    setViewPlane(ox, oy, oz, ux, uy, uz, vx, vy, vz) {
        const ret = wasm.canvas_setViewPlane(this.__wbg_ptr, ox, oy, oz, ux, uy, uz, vx, vy, vz);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * A singlet body's geometry as JSON
     * `{r1,r2,thickness,semiAperture,conic1,conic2}` (an infinite radius is
     * `null`, i.e. a plane), or `null` if `id` is not a singlet.
     * @param {number} id
     * @returns {string}
     */
    singletGeomJSON(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_singletGeomJSON(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * A recognised singlet's **per-surface** parameters:
     * `{"radius1","radius2","thickness","half_ap1","half_ap2","conic_k1",
     * "conic_k2"}` (front = 1, rear = 2), or `null` if the element is not a
     * two-conic singlet.
     * @param {number} id
     * @returns {string}
     */
    singletParamsJson(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_singletParamsJson(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Snap a proposed position for element `id` to nearby optical guides: the
     * optical axis (`y = 0`), and vertex alignment (matching `x`/`y`) with the
     * other elements, within `thresh` world units. Returns
     * `{"x","y","snaps":[…],"guideX","guideY"}`; a `guide` is `null` when that
     * axis did not snap. Enable it from the UI by holding a modifier (§5.2).
     * @param {number} id
     * @param {number} x
     * @param {number} y
     * @param {number} thresh
     * @returns {string}
     */
    snapPointJson(id, x, y, thresh) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_snapPointJson(this.__wbg_ptr, id, x, y, thresh);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * A surface object's `{front, back}` response kinds, or `null` if `id` is not
     * a surface.
     * @param {number} id
     * @returns {string}
     */
    surfaceResponseJSON(id) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_surfaceResponseJSON(this.__wbg_ptr, id);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    toJSON() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_toJSON(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Legacy M1 trace: flat `[ax, ay, bx, by, flux]` per segment.
     * @returns {Float32Array}
     */
    trace() {
        const ret = wasm.canvas_trace(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Interactive spectral trace. Flat array, **9 floats per segment**:
     * `[ax, ay, bx, by, r, g, b, flux, flags]`. Colour is CIE→sRGB of the
     * ray's wavelength; `flags` bit1 = TIR, bit2 = ghost.
     * @returns {Float32Array}
     */
    traceColored() {
        const ret = wasm.canvas_traceColored(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Interactive (f32) trace of a saved history node, for a live gallery
     * thumbnail. Same 9-floats-per-segment layout as `traceColored`; empty if
     * the node id is invalid.
     * @param {number} id
     * @returns {Float32Array}
     */
    traceNodeColored(id) {
        const ret = wasm.canvas_traceNodeColored(this.__wbg_ptr, id);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Trace the authoritative f64 path and project every segment onto the view
     * plane. Eleven floats per segment:
     * `[au, av, bu, bv, r, g, b, flux, flags, dist_a, dist_b]`, where
     * `(au,av)`/`(bu,bv)` are in-plane coordinates, `(r,g,b)` is the segment's
     * linear-light wavelength colour (the same convention as [`Canvas::trace_colored`],
     * so the browser draws 3D rays through the identical HDR `RayLayer`),
     * `flags` is bit1=TIR bit2=ghost, and `dist_*` is the signed distance of each
     * endpoint from the plane so the UI can slab-filter (§10.4). Empty if no scene.
     * @returns {Float32Array}
     */
    traceProjected3D() {
        const ret = wasm.canvas_traceProjected3D(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * The **interactive** f32 projection (§4.1): the same 11-float layout as
     * [`Canvas::trace_projected_3d`], traced on the fast CPU f32 path (`cpu3`) so
     * it can update every pointer-move during a drag. The picture, not the
     * numbers — settle with the f64 method for anything displayed.
     * @returns {Float32Array}
     */
    traceProjected3DFast() {
        const ret = wasm.canvas_traceProjected3DFast(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Reference (f64) trace for the wavefront timeline. Flat array, **11 floats
     * per segment**: `[ax, ay, bx, by, r, g, b, flux, flags, opl0, opl1]`.
     * `opl0`/`opl1` are the cumulative optical path length (mm) at the segment
     * ends — the propagation clock. The shell clips every segment at a common
     * OPL `t` to draw the wavefront at that instant, and reads the largest
     * `opl1` for the timeline's end. `flags` is 0 (layout parity with
     * `traceColored`).
     * @returns {Float32Array}
     */
    traceWavefront() {
        const ret = wasm.canvas_traceWavefront(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Trace the authoritative f64 path and return every segment in **world
     * frame** (CV-B, the embed surface). Eleven floats per segment:
     * `[ax, ay, az, bx, by, bz, r, g, b, flux, flags]` — endpoints in world mm,
     * `(r,g,b)` the segment's linear-light wavelength colour, `flags` bit1=TIR
     * bit2=ghost (the [`Canvas::trace_projected_3d`] convention). The trace runs
     * in f64; this buffer is its downcast picture for Three.js/Konva line
     * geometry. It is forbidden as the source of any displayed number — flux
     * totals, centroids, and spot statistics come from the f64 readout APIs
     * ([`Canvas::first_detector_result_json`] and companions). Empty if no scene.
     * @returns {Float32Array}
     */
    traceWorld3D() {
        const ret = wasm.canvas_traceWorld3D(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * The **interactive** world-frame trace (CV-B): the same 11-float layout as
     * [`Canvas::trace_world_3d`], traced on the fast CPU f32 path (`cpu3`) so it
     * can drive drag-time preview frames. The picture, not the numbers — the
     * settled frame and every displayed number come from the f64 method (§4.1).
     * @returns {Float32Array}
     */
    traceWorld3DFast() {
        const ret = wasm.canvas_traceWorld3DFast(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Move to the parent node, restoring its scene (§5.2). True if it moved.
     * @returns {boolean}
     */
    undo() {
        const ret = wasm.canvas_undo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Per-launch-ray **primary path** with cumulative OPL, for drawing the
     * wavefront as a *connected curve* — the surface of constant optical path
     * (§5.5). Because a wavefront is the locus of equal OPL, joining each ray's
     * OPL = t point across the fan is literally the wavefront at time t; it is
     * curved wherever the rays converge or aberrate. Flat f32 encoding:
     * `[nrays, len₀, (x, y, opl)×len₀, len₁, (x, y, opl)×len₁, …]`, rays in fan
     * order. Ghosts are off here (the primary path defines the front); the shell
     * links each ray's OPL = t point to its neighbour's.
     * @returns {Float32Array}
     */
    wavefrontCurves() {
        const ret = wasm.canvas_wavefrontCurves(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * The display colour of a wavelength (nm) as a CSS `rgb(r,g,b)` string — the
     * same wavelength→colour map the ray renderer uses, so a UI swatch matches
     * the rays. Outside the visible band this is yellow.
     * @param {number} nm
     * @returns {string}
     */
    wavelengthCssColor(nm) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.canvas_wavelengthCssColor(this.__wbg_ptr, nm);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) Canvas.prototype[Symbol.dispose] = Canvas.prototype.free;

/**
 * The openUC2 mode's handle.
 *
 * Holds the catalogue and, once started, the project. Kept separate from
 * [`crate::Canvas`] so the freeform route is untouched by any of this.
 */
export class OpenUc2 {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        OpenUc2Finalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_openuc2_free(ptr, 0);
    }
    /**
     * @returns {number}
     */
    activeLayer() {
        const ret = wasm.openuc2_activeLayer(this.__wbg_ptr);
        return ret;
    }
    /**
     * Attach one fragment asset's `.ocanvas` text.
     * @param {string} asset_path
     * @param {string} ocanvas
     */
    attachFragment(asset_path, ocanvas) {
        const ptr0 = passStringToWasm0(asset_path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(ocanvas, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_attachFragment(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Begin one settled operation: everything until `endGesture` is one undo
     * step. Wrap a drag in this, or every pointer move becomes its own step.
     */
    beginGesture() {
        wasm.openuc2_beginGesture(this.__wbg_ptr);
    }
    /**
     * Which instance would block moving `instance` to a cell, or `""` for none.
     *
     * A question, not an attempt: the drag preview asks it on every pointer move
     * and must not move anything to find out.
     * @param {string} instance
     * @param {number} gx
     * @param {number} gy
     * @param {number} gz
     * @returns {string}
     */
    blockerFor(instance, gx, gy, gz) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.openuc2_blockerFor(this.__wbg_ptr, ptr0, len0, gx, gy, gz);
            deferred2_0 = ret[0];
            deferred2_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Which instance would block a *copy* of `instance` at a cell.
     *
     * The original blocks here and does not in `blockerFor`: looking for
     * somewhere to duplicate to has to ask this one, or it will offer a cell the
     * original is standing on.
     * @param {string} instance
     * @param {number} gx
     * @param {number} gy
     * @param {number} gz
     * @returns {string}
     */
    blockerForCopy(instance, gx, gy, gz) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.openuc2_blockerForCopy(this.__wbg_ptr, ptr0, len0, gx, gy, gz);
            deferred2_0 = ret[0];
            deferred2_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * The module list as CSV (§15.8).
     * @returns {string}
     */
    bomCsv() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_bomCsv(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    bomJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_bomJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {boolean}
     */
    canRedo() {
        const ret = wasm.openuc2_canRedo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {boolean}
     */
    canUndo() {
        const ret = wasm.openuc2_canUndo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Catalogue provenance: where it came from and at which commit.
     *
     * Exposed because the UI has to be able to say so. An unpinned or fixture
     * catalogue must not look like a real one (§5.4).
     * @returns {string}
     */
    catalogSourceJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_catalogSourceJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Every catalogue module, flattened for the library list.
     * @returns {string}
     */
    catalogView() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_catalogView(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The grid cell a Canvas point falls in, on the active layer.
     *
     * The snap lives here because the pitch is grid-profile data (§6.4), not a
     * constant. A browser that divided by its own 50 would be wrong the moment a
     * setup used a different profile, and would be wrong silently.
     * @param {number} x
     * @param {number} y
     * @returns {Int32Array}
     */
    cellAt(x, y) {
        const ret = wasm.openuc2_cellAt(this.__wbg_ptr, x, y);
        var v1 = getArrayI32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Drop an override, returning the parameter to the descriptor's design.
     * @param {string} instance
     * @param {string} key
     */
    clearParameter(instance, key) {
        const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_clearParameter(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    clearSelection() {
        wasm.openuc2_clearSelection(this.__wbg_ptr);
    }
    /**
     * The coverage summary (§11.4): what the catalogue does and does not cover.
     * @returns {string}
     */
    coverageJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_coverageJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {number}
     */
    detectorCount() {
        const ret = wasm.openuc2_detectorCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Reference (f64) detector readout as JSON — the only source of a displayed
     * number (§4.1). `null` when there is no such detector.
     * @param {number} idx
     * @returns {string}
     */
    detectorJson(idx) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_detectorJson(this.__wbg_ptr, idx);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {string} instance
     * @param {number} gx
     * @param {number} gy
     * @param {number} gz
     * @returns {string}
     */
    duplicateModule(instance, gx, gy, gz) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.openuc2_duplicateModule(this.__wbg_ptr, ptr0, len0, gx, gy, gz);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    endGesture() {
        wasm.openuc2_endGesture(this.__wbg_ptr);
    }
    /**
     * The flattened `.ocanvas`, for Optiland handoff.
     * @returns {string}
     */
    exportFlatOcanvas() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.openuc2_exportFlatOcanvas(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * The flattened `.ocanvas` *and* what is not faithful about it.
     *
     * `{ocanvas, warnings: [{kind, text}]}`. The caveats travel beside the file
     * rather than inside it, because `.ocanvas` v1 has nowhere to put them and
     * inventing a field would couple the generic format to openUC2 (§5.3, §12.4).
     * Exporting without showing them would hand someone a scene whose idealized
     * parts look like measured ones (§15.9).
     * @returns {string}
     */
    exportFlatOcanvasJson() {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.openuc2_exportFlatOcanvasJson(this.__wbg_ptr);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * The occupied grid cells, for drawing the footprint overlay.
     * @returns {string}
     */
    footprintsJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_footprintsJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The active grid profile, so the UI can draw cells at the right pitch
     * rather than assuming the default one.
     * @returns {string}
     */
    gridJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_gridJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    gridProfilesJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_gridProfilesJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The instance standing on a cell, or `""` for none.
     * @param {number} gx
     * @param {number} gy
     * @param {number} gz
     * @returns {string}
     */
    instanceAtCell(gx, gy, gz) {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_instanceAtCell(this.__wbg_ptr, gx, gy, gz);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The placed instances, for the layout list.
     *
     * Derived from the project on every call rather than pushed to JS and kept:
     * the setup is authoritative, and a mirrored copy is a copy that goes stale.
     * @returns {string}
     */
    instancesView() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_instancesView(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Load a generated `catalog.json`.
     *
     * The document arrives already fetched: this crate never makes a network
     * request, so there is no way for it to quietly pull a newer revision
     * (§5.4).
     * @param {string} json
     */
    loadCatalog(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_loadCatalog(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Open a `.uc2canvas` document.
     * @param {string} json
     */
    loadSetup(json) {
        const ptr0 = passStringToWasm0(json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_loadSetup(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} instance
     * @param {number} gx
     * @param {number} gy
     * @param {number} gz
     */
    moveModule(instance, gx, gy, gz) {
        const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_moveModule(this.__wbg_ptr, ptr0, len0, gx, gy, gz);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    constructor() {
        const ret = wasm.openuc2_new();
        this.__wbg_ptr = ret;
        OpenUc2Finalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Start an empty project on a catalogue grid profile.
     * @param {string} grid_profile_id
     */
    newProject(grid_profile_id) {
        const ptr0 = passStringToWasm0(grid_profile_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_newProject(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The optical geometry, as world-space polylines with their owners.
     *
     * This is the *optics* overlay (§15.5), which is a different thing from the
     * footprint: the footprint is where the cube is, this is what the light
     * actually meets. Only the active layer has objects at all, so this is
     * already layer-filtered by construction.
     *
     * Rebuilt per call, because a drag moves the geometry every frame. It is a
     * handful of elements at a few dozen samples each; the trace it accompanies
     * costs far more.
     * @returns {string}
     */
    opticalOverlayJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_opticalOverlayJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * What an instance's optics were built from, and what may be changed.
     *
     * `{generator, editable: [...], values: {...}, paraxial: {...}}`, or `null`
     * for a module whose optics are a stored fragment. `editable` is the
     * generator's own list, so the UI can only offer fields that actually reach
     * the geometry (§15.7).
     *
     * `paraxial` is the lensmaker's equation for the *current* numbers, computed
     * without the tracer. It is here so the picture can be checked against
     * arithmetic rather than admired: if the rays cross the axis where this says
     * they should, both are probably right.
     * @param {string} instance
     * @returns {string}
     */
    parametersJson(instance) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.openuc2_parametersJson(this.__wbg_ptr, ptr0, len0);
            deferred2_0 = ret[0];
            deferred2_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Place a catalogue module. Returns the new instance id.
     * @param {string} uuid
     * @param {string} version
     * @param {number} gx
     * @param {number} gy
     * @param {number} gz
     * @param {number} rotation
     * @returns {string}
     */
    placeModule(uuid, version, gx, gy, gz, rotation) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(uuid, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passStringToWasm0(version, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.openuc2_placeModule(this.__wbg_ptr, ptr0, len0, ptr1, len1, gx, gy, gz, rotation);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * Every placed port and what it is or is not connected to (§14.6).
     *
     * Advisory: nothing here reaches the tracer. It is what lets the UI say that
     * a cube is one cell out or mounted facing away, which no other overlay can.
     * @returns {string}
     */
    portsJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_portsJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @returns {boolean}
     */
    redo() {
        const ret = wasm.openuc2_redo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * @param {string} instance
     */
    removeModule(instance) {
        const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_removeModule(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} instance
     * @param {number} rotation
     */
    rotateModule(instance, rotation) {
        const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_rotateModule(this.__wbg_ptr, ptr0, len0, rotation);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Serialize the setup.
     * @returns {string}
     */
    saveSetup() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_saveSetup(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The derived scene, for anything that wants to read it directly.
     * @returns {string}
     */
    sceneJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_sceneJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Select the module on a cell. Returns its id, or `""` when the click landed
     * on empty grid, which clears the selection.
     * @param {number} gx
     * @param {number} gy
     * @param {number} gz
     * @returns {string}
     */
    selectAtCell(gx, gy, gz) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.openuc2_selectAtCell(this.__wbg_ptr, gx, gy, gz);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Select a module by name, for a caller that already knows which one it
     * means. Returns `""` if there is no such instance.
     * @param {string} instance
     * @returns {string}
     */
    selectInstance(instance) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.openuc2_selectInstance(this.__wbg_ptr, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * @returns {string}
     */
    selectedInstance() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_selectedInstance(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * @param {number} layer
     */
    setActiveLayer(layer) {
        const ret = wasm.openuc2_setActiveLayer(this.__wbg_ptr, layer);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {boolean} on
     */
    setGhosts(on) {
        wasm.openuc2_setGhosts(this.__wbg_ptr, on);
    }
    /**
     * Change one parameter. Rebuilds the module's optics; the rays follow.
     *
     * The value arrives as JSON text so a number and the string `"inf"` — a
     * plane, which JSON cannot hold as a number — travel the same way.
     * @param {string} instance
     * @param {string} key
     * @param {string} value_json
     */
    setParameter(instance, key, value_json) {
        const ptr0 = passStringToWasm0(instance, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(value_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.openuc2_setParameter(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Interactive f32 segments, for the picture. Same call the freeform Canvas
     * makes, on the project's derived scene.
     * @returns {Float32Array}
     */
    traceColored() {
        const ret = wasm.openuc2_traceColored(this.__wbg_ptr);
        var v1 = getArrayF32FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Step back one settled operation. `false` when there was nothing to undo.
     * @returns {boolean}
     */
    undo() {
        const ret = wasm.openuc2_undo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Fidelity and resolution warnings, as structured rows plus their text.
     * @returns {string}
     */
    warningsJson() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.openuc2_warningsJson(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
}
if (Symbol.dispose) OpenUc2.prototype[Symbol.dispose] = OpenUc2.prototype.free;
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_92b29b0548f8b746: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg___wbindgen_throw_344f42d3211c4765: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./oc_wasm_bg.js": import0,
    };
}

const CanvasFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_canvas_free(ptr, 1));
const OpenUc2Finalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_openuc2_free(ptr, 1));

function getArrayF32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

function getArrayF64FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getFloat64ArrayMemory0().subarray(ptr / 8, ptr / 8 + len);
}

function getArrayI32FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getInt32ArrayMemory0().subarray(ptr / 4, ptr / 4 + len);
}

let cachedFloat32ArrayMemory0 = null;
function getFloat32ArrayMemory0() {
    if (cachedFloat32ArrayMemory0 === null || cachedFloat32ArrayMemory0.byteLength === 0) {
        cachedFloat32ArrayMemory0 = new Float32Array(wasm.memory.buffer);
    }
    return cachedFloat32ArrayMemory0;
}

let cachedFloat64ArrayMemory0 = null;
function getFloat64ArrayMemory0() {
    if (cachedFloat64ArrayMemory0 === null || cachedFloat64ArrayMemory0.byteLength === 0) {
        cachedFloat64ArrayMemory0 = new Float64Array(wasm.memory.buffer);
    }
    return cachedFloat64ArrayMemory0;
}

let cachedInt32ArrayMemory0 = null;
function getInt32ArrayMemory0() {
    if (cachedInt32ArrayMemory0 === null || cachedInt32ArrayMemory0.byteLength === 0) {
        cachedInt32ArrayMemory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachedInt32ArrayMemory0;
}

function getStringFromWasm0(ptr, len) {
    return decodeText(ptr >>> 0, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function passArrayF64ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 8, 8) >>> 0;
    getFloat64ArrayMemory0().set(arg, ptr / 8);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedFloat32ArrayMemory0 = null;
    cachedFloat64ArrayMemory0 = null;
    cachedInt32ArrayMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('oc_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
