/* tslint:disable */
/* eslint-disable */

/**
 * The opaque handle JS holds. Owns the authoritative scene.
 */
export class Canvas {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The glass scatter as JSON: `[{"name","nd","vd"}, ...]`.
     */
    abbeGlassesJson(): string;
    /**
     * The convex hull of the real-glass region as a flat `[vd, nd, ...]` list.
     * Outside it, glass is "unobtainable" (hatch it in the UI).
     */
    abbeHull(): Float64Array;
    activeLayer(): number;
    /**
     * Add a circular aperture stop at `(x,y)`, opening radius `opening` mm,
     * tilted `tilt_deg`. Rays inside the opening pass; the rest are absorbed.
     * Returns the new object id. Bumps the revision.
     */
    addAperture(x: number, y: number, opening: number, tilt_deg: number): number;
    /**
     * Add a square area detector at `(x,y)`, half-size `half` mm, its face normal
     * tilted `tilt_deg` in the meridional plane (same convention as surfaces and
     * apertures). 64×64 bins. Returns the new object id. Bumps the revision.
     */
    addAreaDetector(x: number, y: number, half: number, tilt_deg: number): number;
    /**
     * Add a collimated monochromatic source. `aim_deg` is the beam direction.
     */
    addCollimatedSource(x: number, y: number, aim_deg: number, half_width: number, rays: number, lambda_um: number): void;
    /**
     * Add a detector segment. Returns its index.
     */
    addDetector(x0: number, y0: number, x1: number, y1: number, bins: number): number;
    /**
     * Commit a freehand stroke as an optical element: fit the stroke, extrude
     * the selected rung's surface into a thin glass body, and add it. Pass
     * `rung = -1` to use the auto-selected rung. Returns the new element id, or
     * `-1` for a degenerate stroke.
     */
    addFittedElement(flat_xy: Float64Array, tol_um: number, rung: number, thickness: number, nd: number, vd: number, mirror: boolean): number;
    /**
     * Add a new (visible) layer; returns its id.
     */
    addLayer(name: string): number;
    /**
     * Add a plane mirror segment from `(x0,y0)` to `(x1,y1)`.
     */
    addMirror(x0: number, y0: number, x1: number, y1: number): number;
    /**
     * Add a round optical element (a flat plate) at `(x,y)`, radius `radius` mm,
     * tilted `tilt_deg` in the meridional plane. Defaults to a front-surface
     * mirror (front reflective, back clear); reconfigure with `setSurfaceResponse`.
     * Returns the new object id. Bumps the revision.
     */
    addPlanarElement(x: number, y: number, radius: number, tilt_deg: number): number;
    /**
     * Add a planar mirror spanning the meridional segment `(ax,ay)`→`(bx,by)`
     * (view-plane mm) — the "draw a fold mirror" tool. Returns the new object id,
     * or `-1` for a degenerate segment / no scene. Bumps the revision.
     */
    addPlanarMirror(ax: number, ay: number, bx: number, by: number, reflectivity: number): number;
    /**
     * Add a glass prism at `(x,y)`: an equilateral triangle of side `side` mm,
     * extruded out of plane, glass `(nd,vd)`, tilted `tilt_deg`. Returns the new
     * body id. Bumps the revision.
     */
    addPrism(x: number, y: number, side: number, tilt_deg: number, nd: number, vd: number): number;
    /**
     * Add a biconvex singlet centred at `(x, y)`. Returns its element id.
     */
    addSinglet(x: number, y: number, radius: number, thickness: number, half_ap: number, nd: number, vd: number): number;
    /**
     * Add a collimated white beam. Sampled with a dense equal-energy spectrum
     * (`lines` wavelengths across the visible) so the additive sum is neutral
     * white and dispersion resolves as a smooth rainbow (§5.4/§5.5).
     */
    addWhiteBeam(x: number, y: number, aim_deg: number, half_width: number, rays: number, lines: number): void;
    /**
     * An aperture's clear opening as `{"inner","outer"}` (min / max radius that
     * passes, mm), or `null` if `id` is not an aperture. A plain disc opening
     * reports `inner: 0`.
     */
    apertureOpeningJSON(id: number): string;
    /**
     * An extruded body's local profile + z-extents, for drawing a prism in 3D:
     * `{zMin, zMax, points:[[x,y],...]}` (polygon vertices, local frame), or
     * `null` if `id` is not an extruded profile body.
     */
    bodyExtrudeJSON(id: number): string;
    /**
     * A body's bulk glass as JSON `{nd,vd}` (an Abbe point), or `null` if `id` is
     * not a body or its material is not an Abbe point (catalog glass, mirror, …).
     */
    bodyGlassJSON(id: number): string;
    canRedo(): boolean;
    canUndo(): boolean;
    /**
     * The capability report for the loaded scene (§3.5): which physics the f64
     * reference supports, approximates, or rejects, each with the object. JSON
     * `{supported,exact,approximated,rejected}`, or `null` if none is loaded.
     */
    capabilityReportJSON(): string;
    /**
     * Duplicate a body offset by `(dx,dy,dz)`, with fresh ids. Returns the new
     * body id, or `-1` if `id` is not a body. Bumps the revision.
     */
    cloneBody3D(id: number, dx: number, dy: number, dz: number): number;
    /**
     * Serialize an element to a JSON string for the clipboard. Robust to later
     * deletions/re-indexing (unlike an id), so copy → delete → paste is safe.
     * Returns `"null"` if there is no such element.
     */
    cloneElementJson(id: number): string;
    /**
     * Snapshot the current state as a new child of the current node and move
     * there (§5.2). Returns the new node id, or -1 if nothing changed.
     */
    commit(label: string): number;
    currentHistoryNode(): number;
    /**
     * Delete an element and re-index the fitted-surface and pin tables so ids
     * stay equal to positions (the scene uses index ids). Returns true if an
     * element was removed. The caller must clear/relocate its own `selected`.
     */
    deleteElement(id: number): boolean;
    /**
     * Delete any object or source by id. Bumps the revision. `false` if nothing
     * matched.
     */
    deleteObject3D(id: number): boolean;
    /**
     * Per-hit spot-diagram records for the area detector with id `detector_id`,
     * same flat f32 layout as [`Canvas::first_detector_hits_f32`]. Empty if there
     * is no 3D scene or no such detector. Lets the browser show whichever
     * detector is selected when a scene has several.
     */
    detectorHitsF32(detector_id: number): Float32Array;
    /**
     * Reference (f64) detector readout as JSON — the honest numbers (§4.1).
     * `{"hits","flux","centroid","opl","bins":[...]}`; `null` if no such
     * detector or no hits.
     */
    detectorJson(idx: number): string;
    /**
     * The f64 reference readout for a detector by id (§4.1: the honest numbers).
     * JSON `{hits, totalIncident, totalSignal, cellArea, centroid, meanOpl,
     * bins, incident}`, or `null` if there is no such detector.
     */
    detectorResultJSON(detector_id: number): string;
    elementCount(): number;
    /**
     * The fitted ladder for a committed element (§5.3), for the inspector's
     * complexity slider: `{current, chosen, tol_um, rungs:[{level,name,dof,
     * residual_um,rms_um}]}`. `null` if `id` is not a fitted element.
     */
    elementFitJson(id: number): string;
    /**
     * The element's boundary as a closed world-space polyline `[x,y,…]` — for
     * drawing the actual optic (so a freehand-drawn surface is visible).
     */
    elementOutline(id: number): Float32Array;
    /**
     * The element's rigid transform: `{"x","y","rot_deg"}`, or `null`.
     */
    elementTransformJson(id: number): string;
    /**
     * Per-element metadata for drawing handles / ghosting locked elements:
     * `[{"id","x","y","rot_deg","locked","kind"}]`. `kind` is
     * `singlet|fitted|mirror|other`.
     */
    elementsOverlayJson(): string;
    /**
     * Per-hit records on the scene's first area detector, for a **spot diagram**
     * (§6.9): the actual ray-detector intersection points, not a binned grid.
     * One trace with hit-recording on (bounded); flat f32 layout
     * `[halfW, halfH, n, (u, v, r, g, b, flux) × n]` where `(u,v)` are the
     * detector-local mm coordinates and `(r,g,b)` the linear-light wavelength
     * colour (same convention as the ray renderer). Empty if no 3D scene /
     * detector. Records are capped at `max_records`, so a very dense beam shows a
     * representative sample rather than every ray.
     */
    firstDetectorHitsF32(): Float32Array;
    /**
     * The f64 readout for the scene's first area detector (the common case: one
     * detector), same JSON as [`Canvas::detector_result_json`], or `null` if
     * there is no 3D scene or no detector. Saves the browser from tracking ids
     * for the default single-detector scene.
     */
    firstDetectorResultJSON(): string;
    /**
     * The first source's kind + params, for the picker UI to initialise:
     * `{kind, p0, p1, samples}`, or `null` if there is no source.
     */
    firstSourceJSON(): string;
    /**
     * The first source's wavelengths in nanometres (weights folded in as repeated
     * samples are not — this returns the distinct lines), as a JSON array
     * `[{nm, weight}]`, or `null` if there is no source.
     */
    firstSourceWavelengthsJSON(): string;
    /**
     * Fit a freehand stroke (`flat_xy` = `[x0,y0,x1,y1,...]`, world mm) against
     * the whole complexity ladder **without committing** — the live preview
     * while drawing. Returns JSON:
     * `{chosen, tol_um, rungs:[{level,name,dof,residual_um,rms_um,curve:[x,y,…]}]}`.
     * `curve` is a sampled polyline of that rung's fitted surface, so the
     * complexity slider can redraw any rung for free (no refit).
     */
    fitStroke(flat_xy: Float64Array, tol_um: number): string;
    /**
     * The whole undo tree for the sidebar (§5.2) / variation gallery (§5.6):
     * `{current, nodes:[{id,seq,parent,label,children:[…]}]}`.
     */
    historyJson(): string;
    /**
     * Jump to an arbitrary node — a branch click in the sidebar or a variant
     * in the gallery (§5.6). Returns true if the id is valid.
     */
    historyJumpTo(id: number): boolean;
    /**
     * Reset the history to a single root node snapshotting the current state.
     * The shell calls this once after building its demo scene, so undo does
     * not walk back into the empty start document.
     */
    historyReset(label: string): void;
    isElementLocked(id: number): boolean;
    /**
     * Is `(n_d, V_d)` a physically obtainable glass (inside the hull)?
     */
    isObtainable(nd: number, vd: number): boolean;
    isParamPinned(id: number, name: string): boolean;
    /**
     * All layers: `[{id,name,visible,opacity,count}]`, `count` = elements on
     * the layer.
     */
    layersJson(): string;
    /**
     * Replace the whole scene from an `.ocanvas` document (the "Open…" action).
     * The JSON is version-checked (a future-version file is rejected), then the
     * scene, pins, active layer, and freehand-fit state are reset and the undo
     * history is re-rooted so undo cannot walk back into the previous document.
     * Throws with a readable message if the document is not loadable.
     */
    loadJSON(json: string): void;
    /**
     * Open an `.ocanvas` document of either version into the canonical 3D scene.
     * v1 is migrated with **no third dimension invented** (bodies become
     * `PlanarOnly`); v2 parses directly (§11.2). Returns a load-report JSON:
     * `{dimension, migratedFromV1, unresolvedThirdDimension, planarOnlyBodies,
     * lineProbeDetectors, legacySources, notes, previewMode}`. Throws with a
     * readable message if the document is not loadable.
     */
    loadScene3JSON(json: string): string;
    maxGhostBounces(): number;
    moveElement(id: number, x: number, y: number): void;
    constructor();
    /**
     * Initialize the canonical 3D scene to the default authoring scene: a
     * biconvex singlet at the origin, a collimated beam from the left, and an
     * area detector near the focus. Bumps the revision. Returns the singlet's
     * body id, so the browser can select it.
     */
    newDefaultScene3(): number;
    /**
     * Reference (f64) detector readout for a saved node, so variants are
     * compared on the *same* detector (§5.6). `{hits,flux,centroid,opl}`, or
     * `null`.
     */
    nodeDetectorJson(id: number, idx: number): string;
    /**
     * A one-line summary of a node for the gallery card:
     * `{label,seq,elements,sources,detectors}`, or `null`.
     */
    nodeSummaryJson(id: number): string;
    /**
     * Paste a previously [`clone_element_json`]'d element, offset by `(dx, dy)`
     * world units. The paste is unlocked and editable. Returns the new element
     * id, or `-1` if the JSON did not parse. (A pasted freehand element is a
     * plain body — its fit ladder is not carried, so it has no complexity
     * slider; its geometry is preserved exactly.)
     */
    pasteElement(json: string, dx: number, dy: number): number;
    /**
     * The pinned parameter names for an element, as a JSON string array.
     */
    pinnedParamsJson(id: number): string;
    /**
     * How the browser should preview the scene (§10.3): `"exact_planar"`,
     * `"full_3d"`, `"legacy_planar"`, or `"none"` when nothing is loaded. This
     * is the badge; it never labels a legacy result full 3D.
     */
    previewMode(): string;
    /**
     * Move to the most recently created child, restoring it. True if it moved.
     */
    redo(): boolean;
    /**
     * Remove a layer, merging its elements onto layer 0 and re-indexing the
     * `layer` field of every element above it. The last layer cannot be
     * removed. Returns true on success.
     */
    removeLayer(id: number): boolean;
    renameLayer(id: number, name: string): boolean;
    rotateElement(id: number, rot: number): void;
    /**
     * The canonical 3D scene as v2 JSON, or `""` if none is loaded.
     */
    scene3JSON(): string;
    /**
     * The optical elements' cross-section with the view plane (§10.4), for
     * drawing the 2D layout — a lens as its meridional profile, a sphere as a
     * circle, a mirror or detector as a line. A JSON array of polylines
     * `[{kind, closed, pts:[u,v,...]}]` in view-plane coordinates; `[]` if no
     * scene is loaded.
     */
    sceneCrossSectionJSON(): string;
    /**
     * The loaded scene's dimension (`3`), or `0` if no 3D scene is loaded.
     */
    sceneDimension(): number;
    /**
     * The 3D objects for the inspector: each body's id, geometry kind, 3D
     * construction, whether its third dimension is resolved, and its world
     * position. JSON array `[{id,kind,construction,is3d,pos:[x,y,z]}]`; empty if
     * no scene is loaded. This is where "construction and missing depth are
     * visible" (§13).
     */
    sceneObjectsJSON(): string;
    /**
     * The current scene revision. A settled f64 result carries the revision it
     * was traced at; the UI discards a result whose revision is not the latest.
     */
    sceneRevision(): number;
    setActiveLayer(id: number): void;
    /**
     * Set an aperture's clear opening to the ring `inner..outer` mm (min / max
     * radius that passes). `inner = 0` is a plain hole; a positive inner radius
     * adds a central obstruction. Bumps the revision. `false` (scene unchanged)
     * if the radii are invalid (`0 <= inner < outer` required) or `id` is not an
     * aperture.
     */
    setApertureOpening(id: number, inner: number, outer: number): boolean;
    /**
     * Set a body's bulk glass to an Abbe point `(nd, vd)`. Bumps the revision.
     * `false` if `id` is not a body.
     */
    setBodyGlassAbbe(id: number, nd: number, vd: number): boolean;
    /**
     * Move a body so its world position becomes `(x, y, z)` — the drag authoring
     * action (§10.5: an in-plane move translates the body). Bumps the revision.
     * Returns `false` if there is no such body.
     */
    setBodyPosition(body_id: number, x: number, y: number, z: number): boolean;
    /**
     * Apply an Abbe-map point `(n_d, V_d)` to an element (the picker's live
     * feedback, §5.4). Uses the closed-form Cauchy dispersion.
     */
    setElementAbbe(id: number, nd: number, vd: number): void;
    /**
     * Move a fitted element to a different rung of its ladder (the complexity
     * slider, §5.3) — re-extrudes the body in place. Returns the new max
     * residual in microns, or `-1` if `id` is not a fitted element / is pinned.
     */
    setElementFitRung(id: number, rung: number): number;
    /**
     * Snap an element to a named catalog glass (full Sellmeier). Returns true
     * if the name was found.
     */
    setElementGlass(id: number, name: string): boolean;
    /**
     * Assign an element to a layer (§5.6). Returns true on success.
     */
    setElementLayer(elem_id: number, layer_id: number): boolean;
    /**
     * Lock (or unlock) a whole element — it then rejects every edit and is
     * drawn ghosted in the UI (§5.1). Returns the new locked state.
     */
    setElementLocked(id: number, locked: boolean): boolean;
    /**
     * Set position, honouring per-axis pins and the element lock (§5.2). A
     * pinned coordinate keeps its current value. Returns true if anything moved.
     */
    setElementPos(id: number, x: number, y: number): boolean;
    /**
     * Set rotation in degrees, honouring the `rot` pin and lock.
     */
    setElementRotDeg(id: number, deg: number): boolean;
    /**
     * Toggle the ghost layer (Fresnel back-reflections, §5.5).
     */
    setGhosts(on: boolean): void;
    setLayerOpacity(id: number, opacity: number): boolean;
    setLayerVisible(id: number, visible: boolean): boolean;
    /**
     * Set the ghost reflection-generation cap `G` (§4.2): how many nested
     * Fresnel back-reflections to follow. `0` = none, `1` = single ghosts, `2`
     * = ghosts-of-ghosts, … This is the ray-explosion knob; the number of
     * *elements* is unlimited (the primary path auto-sizes to the scene).
     */
    setMaxGhostBounces(g: number): void;
    /**
     * Move any object or source by id in world space (§10.5). Bumps the
     * revision. `false` if no object has that id or there is no 3D scene.
     */
    setObjectPosition(id: number, x: number, y: number, z: number): boolean;
    /**
     * Rotate an object in the meridional plane (right-handed about +Z), degrees.
     * Bumps the revision. `false` if no object has that id.
     */
    setObjectRotationZDeg(id: number, deg: number): boolean;
    /**
     * Pin (or unpin) a single named parameter of an element: one of
     * `x`,`y`,`rot`,`radius`,`thickness`,`conic_k`,`half_ap`,`fit`. Returns the
     * new pinned state.
     */
    setParamPinned(id: number, name: string, pinned: boolean): boolean;
    /**
     * Replace a singlet body's geometry. Refuses (returns `false`, scene
     * unchanged) if `id` is not a singlet or the geometry is not revolvable — a
     * bad card edit never corrupts the scene. Bumps the revision on success.
     */
    setSingletGeom(id: number, r1: number, r2: number, thickness: number, semi_aperture: number, conic1: number, conic2: number): boolean;
    /**
     * Rebuild a singlet from **per-surface** numeric parameters (the inspector's
     * numeric twin, §5.2). The two faces are independent: `radius1`/`radius2`,
     * `half_ap1`/`half_ap2`, `conic_k1`/`conic_k2`. Each parameter honours its
     * own pin; the whole edit honours the element lock. Returns true on success.
     */
    setSingletParams(id: number, radius1: number, radius2: number, thickness: number, half_ap1: number, half_ap2: number, conic_k1: number, conic_k2: number): boolean;
    /**
     * Slice half-thickness in mm for filtering projected paths by distance from
     * the plane (§10.4). `0` shows everything projected.
     */
    setSliceThickness(mm: number): void;
    /**
     * Reconfigure the scene's first source (the light-source picker, §6.6).
     * `kind` ∈ `collimated_rect` (p0 = ⌀Y, p1 = ⌀X mm) / `collimated_disc`
     * (p0 = ⌀ mm) / `point` (p0 = cone half-angle °) / `lambertian` (p0 = ⌀ mm);
     * `samples` is the ray count. Bumps the revision. `false` if no scene/source
     * or an unknown kind.
     */
    setSourceConfig(kind: string, p0: number, p1: number, samples: number): boolean;
    /**
     * Set the spatial ray count of a source — raise it to fill the beam into a
     * continuous, homogeneous wavefront (brightness is flux-normalized, so the
     * picture stays balanced as rays fill in).
     */
    setSourceRays(idx: number, rays: number): void;
    /**
     * Set the spatial ray count of the scene's first source (the ray-density
     * control). Bumps the revision. `false` if there is no 3D scene or source.
     */
    setSourceSamples(samples: number): boolean;
    /**
     * Set the first source's wavelengths. `nm` are the wavelengths in nanometres
     * and `weights` their relative weights (equal weights if `weights` is empty
     * or a different length). At least one positive wavelength is required.
     * Bumps the revision. `false` if there is no source or no usable line.
     */
    setSourceWavelengths(nm: Float64Array, weights: Float64Array): boolean;
    /**
     * Set a surface object's front/back responses (`mirror`/`absorb`/`clear`/
     * `refract`). Bumps the revision. `false` for an unknown kind / non-surface.
     */
    setSurfaceResponse(id: number, front: string, back: string): boolean;
    /**
     * Set a surface object's meridional tilt (its normal's X–Y angle, degrees).
     * Bumps the revision. `false` for a non-surface id.
     */
    setSurfaceTiltZDeg(id: number, deg: number): boolean;
    /**
     * Set the plane the 2D Canvas slices/projects (§10.1). `u` and `v` are the
     * in-plane axes; they must be perpendicular. Throws on a degenerate or
     * sheared basis. The view is derived, so this does not bump the revision.
     */
    setViewPlane(ox: number, oy: number, oz: number, ux: number, uy: number, uz: number, vx: number, vy: number, vz: number): void;
    /**
     * A singlet body's geometry as JSON
     * `{r1,r2,thickness,semiAperture,conic1,conic2}` (an infinite radius is
     * `null`, i.e. a plane), or `null` if `id` is not a singlet.
     */
    singletGeomJSON(id: number): string;
    /**
     * A recognised singlet's **per-surface** parameters:
     * `{"radius1","radius2","thickness","half_ap1","half_ap2","conic_k1",
     * "conic_k2"}` (front = 1, rear = 2), or `null` if the element is not a
     * two-conic singlet.
     */
    singletParamsJson(id: number): string;
    /**
     * Snap a proposed position for element `id` to nearby optical guides: the
     * optical axis (`y = 0`), and vertex alignment (matching `x`/`y`) with the
     * other elements, within `thresh` world units. Returns
     * `{"x","y","snaps":[…],"guideX","guideY"}`; a `guide` is `null` when that
     * axis did not snap. Enable it from the UI by holding a modifier (§5.2).
     */
    snapPointJson(id: number, x: number, y: number, thresh: number): string;
    /**
     * A surface object's `{front, back}` response kinds, or `null` if `id` is not
     * a surface.
     */
    surfaceResponseJSON(id: number): string;
    toJSON(): string;
    /**
     * Legacy M1 trace: flat `[ax, ay, bx, by, flux]` per segment.
     */
    trace(): Float32Array;
    /**
     * Interactive spectral trace. Flat array, **9 floats per segment**:
     * `[ax, ay, bx, by, r, g, b, flux, flags]`. Colour is CIE→sRGB of the
     * ray's wavelength; `flags` bit1 = TIR, bit2 = ghost.
     */
    traceColored(): Float32Array;
    /**
     * Interactive (f32) trace of a saved history node, for a live gallery
     * thumbnail. Same 9-floats-per-segment layout as `traceColored`; empty if
     * the node id is invalid.
     */
    traceNodeColored(id: number): Float32Array;
    /**
     * Trace the authoritative f64 path and project every segment onto the view
     * plane. Eleven floats per segment:
     * `[au, av, bu, bv, r, g, b, flux, flags, dist_a, dist_b]`, where
     * `(au,av)`/`(bu,bv)` are in-plane coordinates, `(r,g,b)` is the segment's
     * linear-light wavelength colour (the same convention as [`Canvas::trace_colored`],
     * so the browser draws 3D rays through the identical HDR `RayLayer`),
     * `flags` is bit1=TIR bit2=ghost, and `dist_*` is the signed distance of each
     * endpoint from the plane so the UI can slab-filter (§10.4). Empty if no scene.
     */
    traceProjected3D(): Float32Array;
    /**
     * The **interactive** f32 projection (§4.1): the same 11-float layout as
     * [`Canvas::trace_projected_3d`], traced on the fast CPU f32 path (`cpu3`) so
     * it can update every pointer-move during a drag. The picture, not the
     * numbers — settle with the f64 method for anything displayed.
     */
    traceProjected3DFast(): Float32Array;
    /**
     * Reference (f64) trace for the wavefront timeline. Flat array, **11 floats
     * per segment**: `[ax, ay, bx, by, r, g, b, flux, flags, opl0, opl1]`.
     * `opl0`/`opl1` are the cumulative optical path length (mm) at the segment
     * ends — the propagation clock. The shell clips every segment at a common
     * OPL `t` to draw the wavefront at that instant, and reads the largest
     * `opl1` for the timeline's end. `flags` is 0 (layout parity with
     * `traceColored`).
     */
    traceWavefront(): Float32Array;
    /**
     * Trace the authoritative f64 path and return every segment in **world
     * frame** (CV-B, the embed surface). Eleven floats per segment:
     * `[ax, ay, az, bx, by, bz, r, g, b, flux, flags]` — endpoints in world mm,
     * `(r,g,b)` the segment's linear-light wavelength colour, `flags` bit1=TIR
     * bit2=ghost (the [`Canvas::trace_projected_3d`] convention). The trace runs
     * in f64; this buffer is its downcast picture for Three.js/Konva line
     * geometry. It is forbidden as the source of any displayed number — flux
     * totals, centroids, and spot statistics come from the f64 readout APIs
     * ([`Canvas::first_detector_result_json`] and companions). Empty if no scene.
     */
    traceWorld3D(): Float32Array;
    /**
     * The **interactive** world-frame trace (CV-B): the same 11-float layout as
     * [`Canvas::trace_world_3d`], traced on the fast CPU f32 path (`cpu3`) so it
     * can drive drag-time preview frames. The picture, not the numbers — the
     * settled frame and every displayed number come from the f64 method (§4.1).
     */
    traceWorld3DFast(): Float32Array;
    /**
     * CV-C: rigidly move a batch of loaded-scene objects by one delta —
     * the wasm face of [`Scene3::transform_objects`]. `ids` are raw object
     * ids (bodies, standalone surfaces, apertures, detectors, sources, in
     * any mix; a dragged module passes all of its manifest object ids in one
     * call so relative geometry is preserved exactly). `delta` is 7 floats
     * `[px, py, pz, qx, qy, qz, qw]` — world-frame millimetres plus a unit
     * quaternion. Bumps the revision; the next `traceWorld3DFast` call
     * retraces the moved scene (the fast path rebuilds from live scene
     * state). Returns `false` and mutates nothing on an unknown id, a
     * malformed delta, or no loaded scene — the caller's tier-1 reload is
     * the recovery.
     */
    transformObjects3(ids: Float64Array, delta: Float64Array): boolean;
    /**
     * Move to the parent node, restoring its scene (§5.2). True if it moved.
     */
    undo(): boolean;
    /**
     * Per-launch-ray **primary path** with cumulative OPL, for drawing the
     * wavefront as a *connected curve* — the surface of constant optical path
     * (§5.5). Because a wavefront is the locus of equal OPL, joining each ray's
     * OPL = t point across the fan is literally the wavefront at time t; it is
     * curved wherever the rays converge or aberrate. Flat f32 encoding:
     * `[nrays, len₀, (x, y, opl)×len₀, len₁, (x, y, opl)×len₁, …]`, rays in fan
     * order. Ghosts are off here (the primary path defines the front); the shell
     * links each ray's OPL = t point to its neighbour's.
     */
    wavefrontCurves(): Float32Array;
    /**
     * The display colour of a wavelength (nm) as a CSS `rgb(r,g,b)` string — the
     * same wavelength→colour map the ray renderer uses, so a UI swatch matches
     * the rays. Outside the visible band this is yellow.
     */
    wavelengthCssColor(nm: number): string;
}

/**
 * The openUC2 mode's handle.
 *
 * Holds the catalogue and, once started, the project. Kept separate from
 * [`crate::Canvas`] so the freeform route is untouched by any of this.
 */
export class OpenUc2 {
    free(): void;
    [Symbol.dispose](): void;
    activeLayer(): number;
    /**
     * Attach one fragment asset's `.ocanvas` text.
     */
    attachFragment(asset_path: string, ocanvas: string): void;
    /**
     * Begin one settled operation: everything until `endGesture` is one undo
     * step. Wrap a drag in this, or every pointer move becomes its own step.
     */
    beginGesture(): void;
    /**
     * Which instance would block moving `instance` to a cell, or `""` for none.
     *
     * A question, not an attempt: the drag preview asks it on every pointer move
     * and must not move anything to find out.
     */
    blockerFor(instance: string, gx: number, gy: number, gz: number): string;
    /**
     * Which instance would block a *copy* of `instance` at a cell.
     *
     * The original blocks here and does not in `blockerFor`: looking for
     * somewhere to duplicate to has to ask this one, or it will offer a cell the
     * original is standing on.
     */
    blockerForCopy(instance: string, gx: number, gy: number, gz: number): string;
    /**
     * The module list as CSV (§15.8).
     */
    bomCsv(): string;
    bomJson(): string;
    canRedo(): boolean;
    canUndo(): boolean;
    /**
     * Catalogue provenance: where it came from and at which commit.
     *
     * Exposed because the UI has to be able to say so. An unpinned or fixture
     * catalogue must not look like a real one (§5.4).
     */
    catalogSourceJson(): string;
    /**
     * Every catalogue module, flattened for the library list.
     */
    catalogView(): string;
    /**
     * The grid cell a Canvas point falls in, on the active layer.
     *
     * The snap lives here because the pitch is grid-profile data (§6.4), not a
     * constant. A browser that divided by its own 50 would be wrong the moment a
     * setup used a different profile, and would be wrong silently.
     */
    cellAt(x: number, y: number): Int32Array;
    /**
     * Drop an override, returning the parameter to the descriptor's design.
     */
    clearParameter(instance: string, key: string): void;
    clearSelection(): void;
    /**
     * The coverage summary (§11.4): what the catalogue does and does not cover.
     */
    coverageJson(): string;
    detectorCount(): number;
    /**
     * Reference (f64) detector readout as JSON — the only source of a displayed
     * number (§4.1). `null` when there is no such detector.
     */
    detectorJson(idx: number): string;
    duplicateModule(instance: string, gx: number, gy: number, gz: number): string;
    endGesture(): void;
    /**
     * The flattened `.ocanvas`, for Optiland handoff.
     */
    exportFlatOcanvas(): string;
    /**
     * The flattened `.ocanvas` *and* what is not faithful about it.
     *
     * `{ocanvas, warnings: [{kind, text}]}`. The caveats travel beside the file
     * rather than inside it, because `.ocanvas` v1 has nowhere to put them and
     * inventing a field would couple the generic format to openUC2 (§5.3, §12.4).
     * Exporting without showing them would hand someone a scene whose idealized
     * parts look like measured ones (§15.9).
     */
    exportFlatOcanvasJson(): string;
    /**
     * The occupied grid cells, for drawing the footprint overlay.
     */
    footprintsJson(): string;
    /**
     * The active grid profile, so the UI can draw cells at the right pitch
     * rather than assuming the default one.
     */
    gridJson(): string;
    gridProfilesJson(): string;
    /**
     * The instance standing on a cell, or `""` for none.
     */
    instanceAtCell(gx: number, gy: number, gz: number): string;
    /**
     * The placed instances, for the layout list.
     *
     * Derived from the project on every call rather than pushed to JS and kept:
     * the setup is authoritative, and a mirrored copy is a copy that goes stale.
     */
    instancesView(): string;
    /**
     * Load a generated `catalog.json`.
     *
     * The document arrives already fetched: this crate never makes a network
     * request, so there is no way for it to quietly pull a newer revision
     * (§5.4).
     */
    loadCatalog(json: string): void;
    /**
     * Open a `.uc2canvas` document.
     */
    loadSetup(json: string): void;
    moveModule(instance: string, gx: number, gy: number, gz: number): void;
    constructor();
    /**
     * Start an empty project on a catalogue grid profile.
     */
    newProject(grid_profile_id: string): void;
    /**
     * The optical geometry, as world-space polylines with their owners.
     *
     * This is the *optics* overlay (§15.5), which is a different thing from the
     * footprint: the footprint is where the cube is, this is what the light
     * actually meets. Only the active layer has objects at all, so this is
     * already layer-filtered by construction.
     *
     * Rebuilt per call, because a drag moves the geometry every frame. It is a
     * handful of elements at a few dozen samples each; the trace it accompanies
     * costs far more.
     */
    opticalOverlayJson(): string;
    /**
     * What an instance's optics were built from, and what may be changed.
     *
     * `{generator, editable: [...], values: {...}, paraxial: {...}}`, or `null`
     * for a module whose optics are a stored fragment. `editable` is the
     * generator's own list, so the UI can only offer fields that actually reach
     * the geometry (§15.7).
     *
     * `paraxial` is the lensmaker's equation for the *current* numbers, computed
     * without the tracer. It is here so the picture can be checked against
     * arithmetic rather than admired: if the rays cross the axis where this says
     * they should, both are probably right.
     */
    parametersJson(instance: string): string;
    /**
     * Place a catalogue module. Returns the new instance id.
     */
    placeModule(uuid: string, version: string, gx: number, gy: number, gz: number, rotation: number): string;
    /**
     * Every placed port and what it is or is not connected to (§14.6).
     *
     * Advisory: nothing here reaches the tracer. It is what lets the UI say that
     * a cube is one cell out or mounted facing away, which no other overlay can.
     */
    portsJson(): string;
    redo(): boolean;
    removeModule(instance: string): void;
    rotateModule(instance: string, rotation: number): void;
    /**
     * Serialize the setup.
     */
    saveSetup(): string;
    /**
     * The derived scene, for anything that wants to read it directly.
     */
    sceneJson(): string;
    /**
     * Select the module on a cell. Returns its id, or `""` when the click landed
     * on empty grid, which clears the selection.
     */
    selectAtCell(gx: number, gy: number, gz: number): string;
    /**
     * Select a module by name, for a caller that already knows which one it
     * means. Returns `""` if there is no such instance.
     */
    selectInstance(instance: string): string;
    selectedInstance(): string;
    setActiveLayer(layer: number): void;
    setGhosts(on: boolean): void;
    /**
     * Change one parameter. Rebuilds the module's optics; the rays follow.
     *
     * The value arrives as JSON text so a number and the string `"inf"` — a
     * plane, which JSON cannot hold as a number — travel the same way.
     */
    setParameter(instance: string, key: string, value_json: string): void;
    /**
     * Interactive f32 segments, for the picture. Same call the freeform Canvas
     * makes, on the project's derived scene.
     */
    traceColored(): Float32Array;
    /**
     * Step back one settled operation. `false` when there was nothing to undo.
     */
    undo(): boolean;
    /**
     * Fidelity and resolution warnings, as structured rows plus their text.
     */
    warningsJson(): string;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __wbg_canvas_free: (a: number, b: number) => void;
    readonly canvas_abbeGlassesJson: (a: number) => [number, number];
    readonly canvas_abbeHull: (a: number) => [number, number];
    readonly canvas_activeLayer: (a: number) => number;
    readonly canvas_addAperture: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_addAreaDetector: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_addCollimatedSource: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly canvas_addDetector: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly canvas_addFittedElement: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => number;
    readonly canvas_addLayer: (a: number, b: number, c: number) => number;
    readonly canvas_addMirror: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_addPlanarElement: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_addPlanarMirror: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly canvas_addPrism: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
    readonly canvas_addSinglet: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => number;
    readonly canvas_addWhiteBeam: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => void;
    readonly canvas_apertureOpeningJSON: (a: number, b: number) => [number, number];
    readonly canvas_bodyExtrudeJSON: (a: number, b: number) => [number, number];
    readonly canvas_bodyGlassJSON: (a: number, b: number) => [number, number];
    readonly canvas_canRedo: (a: number) => number;
    readonly canvas_canUndo: (a: number) => number;
    readonly canvas_capabilityReportJSON: (a: number) => [number, number];
    readonly canvas_cloneBody3D: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_cloneElementJson: (a: number, b: number) => [number, number];
    readonly canvas_commit: (a: number, b: number, c: number) => number;
    readonly canvas_currentHistoryNode: (a: number) => number;
    readonly canvas_deleteElement: (a: number, b: number) => number;
    readonly canvas_deleteObject3D: (a: number, b: number) => number;
    readonly canvas_detectorHitsF32: (a: number, b: number) => [number, number];
    readonly canvas_detectorJson: (a: number, b: number) => [number, number];
    readonly canvas_detectorResultJSON: (a: number, b: number) => [number, number];
    readonly canvas_elementCount: (a: number) => number;
    readonly canvas_elementFitJson: (a: number, b: number) => [number, number];
    readonly canvas_elementOutline: (a: number, b: number) => [number, number];
    readonly canvas_elementTransformJson: (a: number, b: number) => [number, number];
    readonly canvas_elementsOverlayJson: (a: number) => [number, number];
    readonly canvas_firstDetectorHitsF32: (a: number) => [number, number];
    readonly canvas_firstDetectorResultJSON: (a: number) => [number, number];
    readonly canvas_firstSourceJSON: (a: number) => [number, number];
    readonly canvas_firstSourceWavelengthsJSON: (a: number) => [number, number];
    readonly canvas_fitStroke: (a: number, b: number, c: number, d: number) => [number, number];
    readonly canvas_historyJson: (a: number) => [number, number];
    readonly canvas_historyJumpTo: (a: number, b: number) => number;
    readonly canvas_historyReset: (a: number, b: number, c: number) => void;
    readonly canvas_isElementLocked: (a: number, b: number) => number;
    readonly canvas_isObtainable: (a: number, b: number, c: number) => number;
    readonly canvas_isParamPinned: (a: number, b: number, c: number, d: number) => number;
    readonly canvas_layersJson: (a: number) => [number, number];
    readonly canvas_loadJSON: (a: number, b: number, c: number) => [number, number];
    readonly canvas_loadScene3JSON: (a: number, b: number, c: number) => [number, number, number, number];
    readonly canvas_maxGhostBounces: (a: number) => number;
    readonly canvas_moveElement: (a: number, b: number, c: number, d: number) => void;
    readonly canvas_new: () => number;
    readonly canvas_newDefaultScene3: (a: number) => number;
    readonly canvas_nodeDetectorJson: (a: number, b: number, c: number) => [number, number];
    readonly canvas_nodeSummaryJson: (a: number, b: number) => [number, number];
    readonly canvas_pasteElement: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_pinnedParamsJson: (a: number, b: number) => [number, number];
    readonly canvas_previewMode: (a: number) => [number, number];
    readonly canvas_redo: (a: number) => number;
    readonly canvas_removeLayer: (a: number, b: number) => number;
    readonly canvas_renameLayer: (a: number, b: number, c: number, d: number) => number;
    readonly canvas_rotateElement: (a: number, b: number, c: number) => void;
    readonly canvas_scene3JSON: (a: number) => [number, number];
    readonly canvas_sceneCrossSectionJSON: (a: number) => [number, number];
    readonly canvas_sceneDimension: (a: number) => number;
    readonly canvas_sceneObjectsJSON: (a: number) => [number, number];
    readonly canvas_sceneRevision: (a: number) => number;
    readonly canvas_setActiveLayer: (a: number, b: number) => void;
    readonly canvas_setApertureOpening: (a: number, b: number, c: number, d: number) => number;
    readonly canvas_setBodyGlassAbbe: (a: number, b: number, c: number, d: number) => number;
    readonly canvas_setBodyPosition: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_setElementAbbe: (a: number, b: number, c: number, d: number) => void;
    readonly canvas_setElementFitRung: (a: number, b: number, c: number) => number;
    readonly canvas_setElementGlass: (a: number, b: number, c: number, d: number) => number;
    readonly canvas_setElementLayer: (a: number, b: number, c: number) => number;
    readonly canvas_setElementLocked: (a: number, b: number, c: number) => number;
    readonly canvas_setElementPos: (a: number, b: number, c: number, d: number) => number;
    readonly canvas_setElementRotDeg: (a: number, b: number, c: number) => number;
    readonly canvas_setGhosts: (a: number, b: number) => void;
    readonly canvas_setLayerOpacity: (a: number, b: number, c: number) => number;
    readonly canvas_setLayerVisible: (a: number, b: number, c: number) => number;
    readonly canvas_setMaxGhostBounces: (a: number, b: number) => void;
    readonly canvas_setObjectPosition: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_setObjectRotationZDeg: (a: number, b: number, c: number) => number;
    readonly canvas_setParamPinned: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_setSingletGeom: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => number;
    readonly canvas_setSingletParams: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => number;
    readonly canvas_setSliceThickness: (a: number, b: number) => void;
    readonly canvas_setSourceConfig: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly canvas_setSourceRays: (a: number, b: number, c: number) => void;
    readonly canvas_setSourceSamples: (a: number, b: number) => number;
    readonly canvas_setSourceWavelengths: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_setSurfaceResponse: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly canvas_setSurfaceTiltZDeg: (a: number, b: number, c: number) => number;
    readonly canvas_setViewPlane: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number];
    readonly canvas_singletGeomJSON: (a: number, b: number) => [number, number];
    readonly canvas_singletParamsJson: (a: number, b: number) => [number, number];
    readonly canvas_snapPointJson: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly canvas_surfaceResponseJSON: (a: number, b: number) => [number, number];
    readonly canvas_toJSON: (a: number) => [number, number];
    readonly canvas_trace: (a: number) => [number, number];
    readonly canvas_traceColored: (a: number) => [number, number];
    readonly canvas_traceNodeColored: (a: number, b: number) => [number, number];
    readonly canvas_traceProjected3D: (a: number) => [number, number];
    readonly canvas_traceProjected3DFast: (a: number) => [number, number];
    readonly canvas_traceWavefront: (a: number) => [number, number];
    readonly canvas_traceWorld3D: (a: number) => [number, number];
    readonly canvas_traceWorld3DFast: (a: number) => [number, number];
    readonly canvas_transformObjects3: (a: number, b: number, c: number, d: number, e: number) => number;
    readonly canvas_undo: (a: number) => number;
    readonly canvas_wavefrontCurves: (a: number) => [number, number];
    readonly canvas_wavelengthCssColor: (a: number, b: number) => [number, number];
    readonly __wbg_openuc2_free: (a: number, b: number) => void;
    readonly openuc2_activeLayer: (a: number) => number;
    readonly openuc2_attachFragment: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly openuc2_beginGesture: (a: number) => void;
    readonly openuc2_blockerFor: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly openuc2_blockerForCopy: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly openuc2_bomCsv: (a: number) => [number, number];
    readonly openuc2_bomJson: (a: number) => [number, number];
    readonly openuc2_canRedo: (a: number) => number;
    readonly openuc2_canUndo: (a: number) => number;
    readonly openuc2_catalogSourceJson: (a: number) => [number, number];
    readonly openuc2_catalogView: (a: number) => [number, number];
    readonly openuc2_cellAt: (a: number, b: number, c: number) => [number, number];
    readonly openuc2_clearParameter: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly openuc2_clearSelection: (a: number) => void;
    readonly openuc2_coverageJson: (a: number) => [number, number];
    readonly openuc2_detectorCount: (a: number) => number;
    readonly openuc2_detectorJson: (a: number, b: number) => [number, number];
    readonly openuc2_duplicateModule: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly openuc2_endGesture: (a: number) => void;
    readonly openuc2_exportFlatOcanvas: (a: number) => [number, number, number, number];
    readonly openuc2_exportFlatOcanvasJson: (a: number) => [number, number, number, number];
    readonly openuc2_footprintsJson: (a: number) => [number, number];
    readonly openuc2_gridJson: (a: number) => [number, number];
    readonly openuc2_gridProfilesJson: (a: number) => [number, number];
    readonly openuc2_instanceAtCell: (a: number, b: number, c: number, d: number) => [number, number];
    readonly openuc2_instancesView: (a: number) => [number, number];
    readonly openuc2_loadCatalog: (a: number, b: number, c: number) => [number, number];
    readonly openuc2_loadSetup: (a: number, b: number, c: number) => [number, number];
    readonly openuc2_moveModule: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly openuc2_new: () => number;
    readonly openuc2_newProject: (a: number, b: number, c: number) => [number, number];
    readonly openuc2_opticalOverlayJson: (a: number) => [number, number];
    readonly openuc2_parametersJson: (a: number, b: number, c: number) => [number, number];
    readonly openuc2_placeModule: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number, number, number];
    readonly openuc2_portsJson: (a: number) => [number, number];
    readonly openuc2_redo: (a: number) => [number, number, number];
    readonly openuc2_removeModule: (a: number, b: number, c: number) => [number, number];
    readonly openuc2_rotateModule: (a: number, b: number, c: number, d: number) => [number, number];
    readonly openuc2_saveSetup: (a: number) => [number, number];
    readonly openuc2_sceneJson: (a: number) => [number, number];
    readonly openuc2_selectAtCell: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly openuc2_selectInstance: (a: number, b: number, c: number) => [number, number, number, number];
    readonly openuc2_selectedInstance: (a: number) => [number, number];
    readonly openuc2_setActiveLayer: (a: number, b: number) => [number, number];
    readonly openuc2_setGhosts: (a: number, b: number) => void;
    readonly openuc2_setParameter: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number];
    readonly openuc2_traceColored: (a: number) => [number, number];
    readonly openuc2_undo: (a: number) => [number, number, number];
    readonly openuc2_warningsJson: (a: number) => [number, number];
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
